// In Models/Product.cs
using System.ComponentModel.DataAnnotations.Schema;

namespace MyWebApp.Models;

public class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18, 2)")]
    public decimal Price { get; set; }

    // Foreign Key for Category
    public int CategoryId { get; set; }
    public Category? Category { get; set; }

    // Foreign Key for Supplier
    public int SupplierId { get; set; }
    public Supplier? Supplier { get; set; }
}