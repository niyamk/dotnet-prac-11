// In Models/Supplier.cs
namespace MyWebApp.Models;

public class Supplier
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public ICollection<Product>? Products { get; set; } // A supplier can supply multiple products
}